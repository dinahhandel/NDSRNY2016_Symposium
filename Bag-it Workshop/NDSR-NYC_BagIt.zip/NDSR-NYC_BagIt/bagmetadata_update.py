# Created by Kathryn Gronsbell from https://github.com/LibraryOfCongress/bagit-python#update-bag-metadata
# For use during the NDSR-NYC Symposium (2016-04-28) and other practice scenarios.
# Script requires 2 arguments:
## Argument 0 : script name
## Argument 1 : path to existing bag

import bagit
import sys

# load the bag
bag = bagit.Bag(sys.argv[1])

# update bag info metadata
bag.info['Internal-Sender-Description'] = 'Hello! This bag was updated on 2016-04-01.'
bag.info['Authors'] = ['Genevieve Havemeyer-King']
bag.save()
